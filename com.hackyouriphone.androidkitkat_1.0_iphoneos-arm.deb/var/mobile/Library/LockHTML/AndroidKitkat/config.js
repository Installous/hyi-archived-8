var AnimatedWallpaper = true;
var ShowRibbon = true;
var ShowWidget = true;
var FooterTextColor = "White";
var ZoomLevel = 100;
var RightSide = true;
var DarkIcon = false;
var CustomText = "Welcome Back Aussie Appz";
