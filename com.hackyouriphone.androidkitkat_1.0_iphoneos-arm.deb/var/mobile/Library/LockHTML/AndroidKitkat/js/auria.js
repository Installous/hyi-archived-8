if (BABYLON.GPUParticleSystem.IsSupported) {
    alert('require webgl2 impl, bye');
    throw new Error('not support webgl2');
}

BABYLON.Effect.ShadersStore["MyRadialPixelShader"] =
    `#ifdef GL_ES
precision highp float;
#endif
varying vec2 vUV; // [0, 1] bottom left origin
void main() {
    float a = 1.0 - distance(vUV, vec2(0.5, 0.5)) * 2.0;
    gl_FragColor = vec4(a, a, a, a); 
}`;

const engine = new BABYLON.Engine(elCanvas, true);
const scene = (() => {
    const scene = new BABYLON.Scene(engine);
    scene.clearColor = new BABYLON.Color4(0, 0, 0, 1);

    const tex = new BABYLON.ProceduralTexture("tex0", 32, 'MyRadial', scene, null, true);
    tex.getAlphaFromRGB = true;

    const tn0 = new BABYLON.TransformNode('empty0', scene);
    const tn1 = new BABYLON.TransformNode('empty1', scene);
    tn1.parent = tn0;
    tn1.position.x = 5;
    BABYLON.Animation.CreateAndStartAnimation('anim0', tn0, 'rotation.y', 30, 60, 0, -Math.PI * 2,
        BABYLON.Animation.ANIMATIONLOOPMODE_CYCLE);

    const gps = new BABYLON.GPUParticleSystem('gps', { capacity: 100000 }, scene);
    gps.particleTexture = tex;
    gps.emitter = tn1;
    gps.createDirectedSphereEmitter(1, new BABYLON.Vector3(50, 0, 0), new BABYLON.Vector3(1000, 100, 100))
    gps.minLifeTime = 0.1;
    gps.maxLifeTime = 0.5;
    gps.addSizeGradient(0, 0.03);
    gps.addSizeGradient(1, 0.01);
    gps.emitRate = 100000;
    gps.minEmitPower = 0.01;
    gps.maxEmitPower = 0.1;
    gps.updateSpeed = 0.005;
    gps.addColorGradient(0, new BABYLON.Color4(1, 0, 0, 1));
    gps.addColorGradient(0.5, new BABYLON.Color4(0, 1, 0, 1));
    gps.addColorGradient(1.0, new BABYLON.Color4(0, 0, 1, 1));
    gps.gravity = new BABYLON.Vector3(0, -10, 0);
    gps.start();

    const mesh0 = BABYLON.MeshBuilder.CreateSphere('mesh0', { diameter: 10 }, scene);

    const camera = new BABYLON.ArcRotateCamera('cam', -Math.PI / 2, Math.PI / 180 * 80, 12, mesh0, scene);
    camera.attachControl(elCanvas);
    camera.lowerRadiusLimit = 10;
    camera.upperRadiusLimit = 40;
    camera.lowerBetaLimit = Math.PI / 180 * 70;
    camera.upperBetaLimit = Math.PI / 180 * 85;

    //scene.debugLayer.show();
    return scene;
})();

engine.runRenderLoop(() => {
    scene.render();
});

addEventListener('resize', () => {
    engine.resize();
});