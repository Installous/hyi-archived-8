var TextColour = "Black"; 
var DotColour = "DarkGrey"; 
var TwentyFourHour = true;
var ZoomLevel = 100;