/* 
follow me on Twitter @imo7and 
*/
var Clock = "12h";  // choose between "12h" or "24h"
var Lang = "en";   // choose between "en" or “ar”

var MyTwitter = "@imo7and";   // follow me on Twitter 