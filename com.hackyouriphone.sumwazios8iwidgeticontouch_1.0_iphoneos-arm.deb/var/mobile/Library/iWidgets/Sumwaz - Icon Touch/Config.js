// iWidget Sumwaz Touch 1.0 // 
// by Svink
// Question ? Follow me on twitter : @Svink77

var ColorsExt = ".png"; // choose extension of the wallpaper / ".jpg" / ".png" /...

/////////////////////

var ChangeClick = true; // DON'T CHANGE !
